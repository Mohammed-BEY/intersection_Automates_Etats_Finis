/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_thp;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author mohammed_bey
 */
//Classe non graphique où se font les traitements
public class Automate {

    private final Controle ctrl = new Controle();
    String chemin = "";
    private final ArrayList<String> result = new ArrayList<>();//contient les états accessibles et coaccessibles

    private final Alphabet alpha;
    private final EnsEtats ensEtats;
    private final EtatInitial etatInit;
    private final EnsEtatsFinaux ensEF;
    AnchorPane contauto;

    public Alphabet getAlpha() {
        return alpha;
    }

    public EnsEtats getEnsEtats() {
        return ensEtats;
    }

    public EtatInitial getEtatInit() {
        return etatInit;
    }

    public EnsEtatsFinaux getEnsEF() {
        return ensEF;
    }

    public EnsInstructions getEnsInst() {
        return ensInst;
    }
    private final EnsInstructions ensInst;

    public String getEtatInitial() {
        return etatInit.tField1.getText();
    }

    public Automate(AnchorPane contauto) {
        this.contauto = contauto;
        alpha = new Alphabet();
        ensEtats = new EnsEtats();
        etatInit = new EtatInitial();
        ensEF = new EnsEtatsFinaux();
        ensInst = new EnsInstructions(contauto);

        contauto.getChildren().add(alpha);
        contauto.getChildren().add(ensEtats);
        contauto.getChildren().add(etatInit);
        contauto.getChildren().add(ensEF);
        contauto.getChildren().add(ensInst);
        //ajuster lesp oditions x et y
        contauto.getChildren().get(1).setLayoutY(23 * 1);
        contauto.getChildren().get(2).setLayoutY(23 * 2);
        contauto.getChildren().get(3).setLayoutY(23 * 3);
        contauto.getChildren().get(4).setLayoutY(23 * 4);
    }

    public String afficherAutomate(AnchorPane contauto) {
        String resultAff = "";
        int j = contauto.getChildren().size();
        for (int i = 0; i < j; i++) {
            resultAff += contauto.getChildren().get(i).toString();
        }
        if (resultAff.endsWith(",")) {
            resultAff = resultAff.substring(0, resultAff.length() - 1);//enlever la dernière virgule   
        }
        resultAff += "}";
        return resultAff;
    }

    public boolean reconnaitreMot(String mot, AnchorPane contauto) {
        chemin = "";//initialiser le chemin
        boolean reconnu = true;
        //tester si le mot ne contient que les symbols définis dans l'alphabet
        ctrl.remplirListS(this);
        ctrl.remplirListIns(this);
        ctrl.remplirListEFIntersection(this);
        int i = 0;
        while (reconnu && i < mot.length()) {
            if (!ctrl.getListSymbols().contains(String.valueOf(mot.charAt(i)))) {//symbol non reconnu
                reconnu = false;
            }
            i++;
        }
        //tous les caracteres constituant le mot appartiennent à l'alphabet
        //vérifier avec les états de l'automate        
        if (reconnu) {
            String Si = ((EtatInitial) contauto.getChildren().get(2)).tField1.getText(),//initialiser Si à l'état initial
                    Sj = "";
            char xi;
            i = 0;
            boolean stop = false;
            while (!stop && i < mot.length()) {
                xi = mot.charAt(i);
                Sj = passInst(Si, xi);
                if (Sj.equals("0")) {//chemin bloqué
                    //Le mot n'est pas reconnu
                    stop = true;
                } else {//aller au prochain symbol
                    i++;
                    chemin += Si + " " + xi + " ";
                    Si = Sj;
                    chemin += Sj + " ,  ";
                }
            }
            if (stop) {//blockage au milieu du mot
                reconnu = false;
            } else if (Sj.equals("0")) {//blockage à la fin
                reconnu = false;
            } else if (ctrl.getListEtatsF().contains(Sj)) {//atteinte de l'etat final (chamin reussi)
                reconnu = true;
            } else {//atteinte du dernier caractere mais le dernier etat n'appartient pas à l'etat final
                reconnu = false;
            }
        }
        return reconnu;
    }

    //détecter quelques éventuelles erreurs
    public String traiter(AnchorPane contauto) {
        String resultTr = "", tmp = "";
        int j = contauto.getChildren().size();
        ctrl.remplirListS(this);
        ctrl.remplirListIns(this);
        ctrl.remplirListE(this);
        tmp = ctrl.getListSymbols().get(ctrl.getListSymbols().size() - 1);//erreur des symbols
        if (!tmp.equals("")) {
            resultTr += tmp;
        }
        resultTr += ((EtatInitial) contauto.getChildren().get(2)).traiter(this);
        resultTr += ((EnsEtatsFinaux) contauto.getChildren().get(3)).traiter(this);
        //les instructions
        resultTr += ctrl.getListIns().get(ctrl.getListIns().size() - 1);//resuperer les erreurs détectées lors du remplissage de la liste des instructions
        for (int k = 5; k < j; k++) {
            resultTr += ((InstructionDecl) contauto.getChildren().get(k)).traiter(ctrl.getListSymbols(), ctrl.getListEtats());
        }
        return resultTr;
    }
    
    //détecter quelques éventuelles erreurs
    public String traiterIntersection(AnchorPane contauto) {
        String resultTr = "", tmp = "";
        int j = contauto.getChildren().size();
        ctrl.remplirListS(this);
        ctrl.remplirListIns(this);
        ctrl.remplirListEIntersection(this);
        tmp = ctrl.getListSymbols().get(ctrl.getListSymbols().size() - 1);//erreur des symbols
        if (!tmp.equals("")) {
            resultTr += tmp;
        }
        resultTr += ((EtatInitial) contauto.getChildren().get(2)).traiterIntersection(this);
        resultTr += ((EnsEtatsFinaux) contauto.getChildren().get(3)).traiterIntersection(this);
        //les instructions
        resultTr += ctrl.getListIns().get(ctrl.getListIns().size() - 1);//resuperer les erreurs détectées lors du remplissage de la liste des instructions
        for (int k = 5; k < j; k++) {
            resultTr += ((InstructionDecl) contauto.getChildren().get(k)).traiter(ctrl.getListSymbols(), ctrl.getListEtats());
        }
        return resultTr;
    }

    //compléter l'automate
    public void completerAuto(AnchorPane contauto) {
        ctrl.remplirListS(this);
        ctrl.remplirListE(this);
        ctrl.remplirListEF(this);
        ctrl.remplirListIns(this);
        String tmp = "", SP = "";
        int sizeCon = contauto.getChildren().size();
        int sizeS = ctrl.getListSymbols().size() - 1,
                sizeE = ctrl.getListEtats().size() - 1;
        for (int i = 0; i < sizeE; i++) {//parcourir tous les états
            for (int j = 0; j < sizeS; j++) {//parcourir tous les symboles
                if (passInst(ctrl.getListEtats().get(i), ctrl.getListSymbols().get(j).charAt(0)).equals("0")) {//il n'y a pas un passage de Si à travers xi
                    //créer un état puit et ajouter l'instruction à la liste des instructions
                    SP = "SP";
                    tmp = ctrl.getListEtats().get(i) + " " + ctrl.getListSymbols().get(j) + " " + "SP";
                    ctrl.getListIns().add(ctrl.getListIns().size() - 1, tmp);
                    InstructionDecl instr = new InstructionDecl(contauto);
                    instr.setInst(tmp);
                    ((InstructionDecl) contauto.getChildren().get(sizeCon - 1)).ajouterEl(instr, contauto);
                    sizeCon++;
                }
            }
        }
        if (!SP.equals("") && !((EnsEtats) contauto.getChildren().get(1)).tField1.getText().contains(SP)) {
            ((EnsEtats) contauto.getChildren().get(1)).tField1.appendText("," + SP);//ajouter l'état puit à l'ensemble des états dans la construction de l'auto
            ctrl.getListEtats().add(ctrl.getListEtats().size() - 1, SP);
        }
    }

    private void etatAccEtCoacc(AnchorPane contauto) {
        ArrayList<String> listAccess = etatsAccessibles(contauto),
                listCoaccess = etatsCoaccessibles();
        result.clear();
        result.addAll(listAccess);
        for (String string : listCoaccess) {
            if (!result.contains(string)) {
                result.add(string);
            }
        }
        listAccess.stream().filter((listAcces) -> (listCoaccess.contains(listAcces))).forEach((listAcces) -> {
            result.remove(listAcces);
        });
        for (String listCoAcc : listCoaccess) {
            if (listAccess.contains(listCoAcc)) {
                result.remove(listCoAcc);
            }
        }
    }

    //réduire un automate
    public void reduireAuto(AnchorPane contauto) {
        ctrl.remplirListIns(this);
        ctrl.remplirListEF(this);
        ctrl.remplirListE(this);
        etatAccEtCoacc(contauto);
        result.stream().forEach((String string) -> {//état non accessible ou non coaccessible
            int j = ctrl.getListIns().size() - 1;
            int tai = 0;
            String tmp = "";
            if (ctrl.getListEtatsF().contains(string)) {//enlever de la liste des états finaux
                ctrl.getListEtatsF().remove(string);
                tai = ctrl.getListEtatsF().size();
                for (int i = 0; i < tai - 1; i++) {
                    tmp += ctrl.getListEtatsF().get(i) + ",";
                }
                int end = tmp.lastIndexOf(",");
                ((EnsEtatsFinaux) contauto.getChildren().get(3)).tField1.setText(tmp.substring(0, end));
            }
            tmp = "";
            if (ctrl.getListEtats().contains(string)) {//enlever de la liste des états
                ctrl.getListEtats().remove(string);
                tai = ctrl.getListEtats().size();
                for (int i = 0; i < tai - 1; i++) {
                    tmp += ctrl.getListEtats().get(i) + ",";
                }
                int end = tmp.lastIndexOf(",");
                ((EnsEtats) contauto.getChildren().get(1)).tField1.setText(tmp.substring(0, end));
            }
            int cptSup = 0;
            j = ctrl.getListIns().size() - 1;
            for (int i = 0; i < j; i++) {//les instructions
                if (ctrl.getListIns().get(i).contains(string)) {
                    ((InstructionDecl) contauto.getChildren().get(4)).supprimerEl(5 + i - cptSup, contauto);
                    cptSup++;
                }
            }
        });
    }

    //recupérer la liste des états accessibles
    private ArrayList etatsAccessibles(AnchorPane contauto) {
        ArrayList<String> listAccess = new ArrayList();
        ctrl.remplirListS(this);
        ctrl.remplirListIns(this);
        String Si = ((EtatInitial) contauto.getChildren().get(2)).tField1.getText(),
                Sj = "";
        char xi = 0;
        listAccess.add(Si);//ajouter l'état initial à la liste
        int j = ctrl.getListSymbols().size() - 1;
        for (int i = 0; i < listAccess.size(); i++) {//les états accessibles            
            Si = listAccess.get(i);
            for (int k = 0; k < j; k++) {//les symboles                 
                xi = ctrl.getListSymbols().get(k).charAt(0);
                Sj = passInst(Si, xi);
                if (!Sj.equals("0") && !listAccess.contains(Sj)) {
                    listAccess.add(Sj);
                }
            }
        }
        return listAccess;
    }

    //recupérer la liste des états coaccessibles
    private ArrayList etatsCoaccessibles() {
        ArrayList<String> listCoaccess = new ArrayList();
        ctrl.remplirListS(this);
        ctrl.remplirListE(this);
        ctrl.remplirListEF(this);
        ctrl.remplirListIns(this);

        String Si = "";
        char xi;
        int f = ctrl.getListEtatsF().size() - 1,
                s = ctrl.getListSymbols().size() - 1;
        for (int i = 0; i < f; i++) {//parcourir la liste de états finaux
            listCoaccess.add(ctrl.getListEtatsF().get(i).replaceAll(" ", ""));//ajouter l'état final comme état coaccessible
        }
        for (int i = 0; i < listCoaccess.size(); i++) {//parcourir la liste de états finaux
            for (int j = 0; j < s; j++) {//la liste des symboles
                //pour chaque caractére
                xi = ctrl.getListSymbols().get(j).charAt(0);
                Si = passInst(xi, listCoaccess.get(i));
                if (!Si.equals("0")) {//il y a des prédécesseurs
                    String tabInsSi[] = Si.split("#");
                    for (String string : tabInsSi) {//ajouter les prédécesseurs des états qui ménent vers l'état final à la liste
                        if (!listCoaccess.contains(string)) {
                            listCoaccess.add(string.replaceAll(" ", ""));//ajouter l'état comme état coaccessible
                        }
                    }
                }
            }
        }
        return listCoaccess;
    }

    //resuperer l'automate tel qu'il est
    public String graphStatus(AnchorPane contauto) {
        String resultGraph = "digraph" + "\n{\n" + "rankdir=LR;\n" + "node [shape = circle, width = 0.5];\n";
        ctrl.remplirListE(this);
        ctrl.remplirListEF(this);
        ctrl.remplirListIns(this);
        int k = 0;
        for (int i = 0; i < ctrl.getListIns().size() - 1; i++) {
            String[] tab = ctrl.getListIns().get(i).split(" ");
            k = 0;
            if (k < tab.length) {
                resultGraph += tab[k] + "->";
                k += 2;
            }
            if (k < tab.length) {
                resultGraph += tab[k];
                k--;
            }
            if (k < tab.length) {
                resultGraph += "[label=\"" + tab[k] + "\",weight=\"" + tab[k] + "\"]\n";
            }
        }
        //colorer les états finaux
        for (int i = 0; i < ctrl.getListEtatsF().size() - 1; i++) {
            for (int l = 0; l < ctrl.getListIns().size() - 1; l++) {
                if (ctrl.getListIns().get(l).contains(ctrl.getListEtatsF().get(i))) {
                    resultGraph += ctrl.getListEtatsF().get(i) + " [style = filled, fillcolor=palegreen ];\n";
                }
            }
        }

        for (int l = 0; l < ctrl.getListIns().size() - 1; l++) {
            //colorer l'état initial
            if (ctrl.getListIns().get(l).contains(((EtatInitial) contauto.getChildren().get(2)).tField1.getText().replaceAll(" ", ""))) {
                resultGraph += ((EtatInitial) contauto.getChildren().get(2)).tField1.getText().replaceAll(" ", "") + " [style = filled, fillcolor=yellow ];\n";
            }
            //colorer l'état puit
            if (ctrl.getListIns().get(l).contains("SP")) {
                resultGraph += "SP" + " [style = filled, fillcolor=orange ];\n";
            }
        }
        resultGraph += "}";
        return resultGraph;
    }

    //récuperer l'automate Intersection tel qu'il est
    public String graphStatusIntersection(AnchorPane contauto) {
        String resultGraph = "digraph" + "\n{\n" + "rankdir=LR;\n" + "node [shape = circle, width = 0.5];\n";
        ctrl.remplirListEIntersection(this);
        ctrl.remplirListEFIntersection(this);
        ctrl.remplirListIns(this);
        int k = 0;
        for (int i = 0; i < ctrl.getListIns().size() - 1; i++) {
            String[] tab = ctrl.getListIns().get(i).split(" ");
            k = 0;
            if (k < tab.length) {
                resultGraph += ctrl.getTabEtatEquiv().get(tab[k]) + "->";
                k += 2;
            }
            if (k < tab.length) {
                resultGraph += ctrl.getTabEtatEquiv().get(tab[k]);
                k--;
            }
            if (k < tab.length) {
                resultGraph += "[label=\"" + tab[k] + "\",weight=\"" + tab[k] + "\"]\n";
            }
        }
        String ch = "";
        //colorer les états finaux
        for (int i = 0; i < ctrl.getListEtatsF().size() - 1; i++) {
            for (int l = 0; l < ctrl.getListIns().size() - 1; l++) {
                if (ctrl.getListIns().get(l).contains(ctrl.getListEtatsF().get(i))) {
                    ch = ctrl.getListEtatsF().get(i);
                    resultGraph += ctrl.getTabEtatEquiv().get(ch) + " [style = filled, fillcolor=palegreen ];\n";
                }
            }
        }
        //colorer l'état initial
        ch = ((EtatInitial) contauto.getChildren().get(2)).tField1.getText().replaceAll(" ", "");
        resultGraph += ctrl.getTabEtatEquiv().get(ch) + " [style = filled, fillcolor=yellow ];\n";

        resultGraph += "}";
        return resultGraph;
    }

    public String etatsEquiv() {
        String result = "";
        //parcourir le tableau associatif des états
        for (Map.Entry<String, String> e : ctrl.getTabEtatEquiv().entrySet()) {
            result += e.getValue() + " -- " + e.getKey() + "\n";
        }
        return result;
    }

    //permet de savoir si on peut passer à travers xi de l'état Si à un état Sj
    public String passInst(String Si, char xi) {
        String result = "";
        int i = 0, j = ctrl.getListIns().size();
        boolean fin = false;
        while (!fin && i < j - 1) {
            String tab[] = ctrl.getListIns().get(i).split(" ");
            if (tab.length == 3) {//instrution complete
                if (tab[0].equals(Si) && tab[1].equals(String.valueOf(xi))) {//il existe une instruction qui permet de passer de Si à Sj à travers xi
                    result = tab[2].replaceAll(" ", "");
                    fin = true;
                }
            }
            i++;
        }
        if (!fin) {
            result = "0";
        }
        return result;
    }

    //permet de savoir si on peut passer à travers xi de l'état Si à un état Sj
    public String SixiSj(String Si, char xi, ArrayList<String> listInst) {
        String result = "";
        int i = 0, j = listInst.size();
        boolean fin = false;
        while (!fin && i < j - 1) {
            String tab[] = listInst.get(i).split(" ");
            if (tab.length == 3) {//instrution complete
                if (tab[0].equals(Si) && tab[1].equals(String.valueOf(xi))) {//il existe une instruction qui permet de passer de Si à Sj à travers xi
                    result = tab[2].replaceAll(" ", "");
                    fin = true;
                }
            }
            i++;
        }
        if (!fin) {
            result = "0";
        }
        return result;
    }

    //permet de savoir s'il y a des états Si tel qu'on peut passer à travers xi de l'état Si à un état Sj
    public String passInst(char xi, String Sj) {
        String result = "";
        int i = 0, j = ctrl.getListIns().size();
        while (i < j - 1) {
            String tab[] = ctrl.getListIns().get(i).split(" ");
            if (tab.length == 3) {//instrution complete
                if (tab[2].equals(Sj) && tab[1].equals(String.valueOf(xi))) {//il existe une instruction qui permet de passer de Si à Sj à travers xi
                    result += tab[0].replaceAll(" ", "") + "#";
                }
            }
            i++;
        }
        if (result.equals("")) {
            result = "0";
        }
        return result;
    }

    //verifier si l'automate est complet ou pas
    public boolean estVide(AnchorPane contauto) {
        boolean resultVide = false;
        for (int i = 0; i < 4; i++) {
            if (((Alphabet) contauto.getChildren().get(0)).tField1.getText().replaceAll(" ", "").equals("")) {
                resultVide = true;
            } else if (((EnsEtats) contauto.getChildren().get(1)).tField1.getText().replaceAll(" ", "").equals("")) {
                resultVide = true;
            } else if (((EtatInitial) contauto.getChildren().get(2)).tField1.getText().replaceAll(" ", "").equals("")) {
                resultVide = true;
            } else if (((EnsEtatsFinaux) contauto.getChildren().get(3)).tField1.getText().replaceAll(" ", "").equals("")) {
                resultVide = true;
            }
        }
        return resultVide;
    }

    //remplir l'auto à partir des listes d'alphabet, ens d'états, ..
    public void remplirAuto(List listAlpha, List listensEtats, String etat0, List listEnsEF, List listEnsInst) {
        String etats = "", alphabet = "", etatsF = "";
        //remplir la liste d'alphabet
        for (int i = 0; i < listAlpha.size() - 1; i++) {
            alphabet += listAlpha.get(i) + ",";
        }
        if (!alphabet.equals("")) {
            alpha.tField1.setText(alphabet.substring(0, alphabet.length() - 1));
        }
        //remplir la liste des états
        for (Object object : listensEtats) {
            etats += "," + object;
        }
        this.ensEtats.tField1.setText(etats.substring(1, etats.length()));
        //remplir l'état initial
        etatInit.tField1.setText(etat0);
        //remplir la liste des états finaux
        for (Object object : listEnsEF) {
            etatsF += object + ",";
        }
        if (!etatsF.equals("")) {
            ensEF.tField1.setText(etatsF.substring(0, etatsF.length() - 1));
        }
        //remplir la liste des instructions
        int i = 4;
        for (Object object : listEnsInst) {
            InstructionDecl instr = new InstructionDecl(contauto);
            instr.setInst((String) object);
            if (i == 4) {
                ((EnsInstructions) contauto.getChildren().get(i)).ajouterEl(instr, contauto);
                i++;
            } else {
                ((InstructionDecl) contauto.getChildren().get(i)).ajouterInstrInter(instr, contauto);
            }
        }
    }
}
