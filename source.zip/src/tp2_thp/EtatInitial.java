/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_thp;

/**
 *
 * @author mohammed_bey
 */
public class EtatInitial extends ClasseMereGraphique {

    public EtatInitial() {
        label1.setText("Etat initial :  ");
        tField1.setPromptText("S0");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(label1, tField1);
    }

    @Override
    public String toString() {
        return "État initial = " + tField1.getText() + "\n";
    }

    //contrôler l'état initial
    public String traiter(Automate auto) {
        String result = "", tmp = ((EtatInitial) auto.contauto.getChildren().get(2)).tField1.getText().replaceAll(" ", "");
        Controle ctrl = new Controle();
        ctrl.remplirListE(auto);
        if (!tmp.equals("")) {
            String[] tab = tmp.split(",");
            if (tab.length > 1) {
                result += "Attention! il y a plus d'un état initial.\n";
            } else {
                try {
                    Double.parseDouble(tField1.getText());
                    result += "Attetntion! l'état initial est constitué uniquement des chiffres.\n";
                } catch (NumberFormatException e) {
                    if (!ctrl.getListEtats().contains(tField1.getText())) {
                        result += "Attention! l'état initial '" + tField1.getText().replaceAll(" ", "") + "' n'a pas été défini.\n";
                    }
                }
            }
        }

        return ctrl.getListEtats().get(ctrl.getListEtats().size() - 1) + result;
    }

    //contrôler l'état initial dans l'auto Intersection
    public String traiterIntersection(Automate auto) {
        String result = "", tmp = ((EtatInitial) auto.contauto.getChildren().get(2)).tField1.getText().replaceAll(" ", "");
        Controle ctrl = new Controle();
        ctrl.remplirListEIntersection(auto);
        if (!tmp.equals("")) {
            boolean fin = false;
            int i = 0, j = 0;
            String string = "";
            while (!fin) {
                j = tmp.indexOf("),", j + 1) + 1;
                if (j == 0) {
                    fin = true;
                    j = tmp.length();
                }
                string = tmp.substring(i, j);
                try {
                    Double.parseDouble(tField1.getText());
                    result += "Attetntion! l'état initial '" + string + "' est constitué uniquement des chiffres.\n";
                } catch (NumberFormatException e) {
                    if (!ctrl.getListEtats().contains(tField1.getText())) {
                        result += "Attention! l'état initial '" + tField1.getText().replaceAll(" ", "") + "' n'a pas été défini.\n";
                    }
                }
                i = j + 1;
            }
        }

        return ctrl.getListEtats().get(ctrl.getListEtats().size() - 1) + result;
    }
}
