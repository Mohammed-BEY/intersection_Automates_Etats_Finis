/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_thp;

/**
 *
 * @author mohammed_bey
 */
public class EnsEtatsFinaux extends ClasseMereGraphique {

    public EnsEtatsFinaux() {
        label1.setText("Ensemble des états finaux = { ");
        label2.setText(" }");
        tField1.setPromptText("S0,S1,...,Sn");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(label1, tField1, label2);
    }

    @Override
    public String toString() {
        return "Ensemble des états finaux = {" + tField1.getText() + "}\n";
    }

    //contrôler les états finaux
    public String traiter(Automate auto) {
        String result = "";
        Controle ctrl = new Controle();
        ctrl.remplirListEF(auto);
        ctrl.remplirListE(auto);
        String tmp = tField1.getText().replaceAll(" ", "");
        String[] tab = tmp.split(",");
        for (String string : tab) {
            if (!ctrl.getListEtats().contains(string)) {
                result += "Attention! l'état final '" + string + "' n'a pas été défini.\n";
            }
        }
        return result + ctrl.getListEtatsF().get(ctrl.getListEtatsF().size() - 1);
    }

    //contrôler les états finaux de l'auton Intersection
    public String traiterIntersection(Automate auto) {
        String result = "";
        Controle ctrl = new Controle();
        ctrl.remplirListEFIntersection(auto);
        ctrl.remplirListEIntersection(auto);
        String tmp = tField1.getText().replaceAll(" ", "");
        if (!tmp.equals("")) {
            boolean fin = false;
            int i = 0, j = 0;
            String string = "";
            while (!fin) {
                j = tmp.indexOf("),", j + 1) + 1;
                if (j == 0) {
                    fin = true;
                    j = tmp.length();
                }
                string = tmp.substring(i, j);
                try {
                    Double.parseDouble(string);
                    result += "Attetntion! l'état final '" + string + "' est constitué uniquement des chiffres.\n";
                } catch (NumberFormatException e) {
                    if (!ctrl.getListEtats().contains(string)) {
                        result += "Attention! l'état final '" + string + "' n'a pas été défini.\n";
                    }
                }
                i = j + 1;
            }
        }

        return result + ctrl.getListEtatsF().get(ctrl.getListEtatsF().size() - 1);
    }
}
