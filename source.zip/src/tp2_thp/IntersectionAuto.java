/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_thp;

import java.util.ArrayList;
import java.util.List;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author mohammed_bey
 */
public class IntersectionAuto {

    public IntersectionAuto() {

    }

    public Automate intersection(Automate auto1, Automate auto2, AnchorPane contauto) {
        String SI1 = "", SI2 = "", tmp1 = "", tmp2 = "", tmp = "";
        contauto.getChildren().clear();
        Automate autoResult = new Automate(contauto);
        Controle ctrl = new Controle();

        ctrl.remplirListS(auto1);
        List<String> listS1 = new ArrayList<>();
        for (String string : ctrl.getListSymbols()) {
            listS1.add(string);
        }
        ctrl.remplirListS(auto2);
        List<String> listS2 = new ArrayList<>();
        for (String string : ctrl.getListSymbols()) {
            listS2.add(string);
        }

        ctrl.remplirListEF(auto1);
        List<String> listEF1 = new ArrayList<>();
        for (String string : ctrl.getListEtatsF()) {
            listEF1.add(string);
        }
        ctrl.remplirListEF(auto2);
        List<String> listEF2 = new ArrayList<>();
        for (String string : ctrl.getListEtatsF()) {
            listEF2.add(string);
        }

        ArrayList<String> listInst1 = new ArrayList<>();
        ctrl.remplirListIns(auto1);
        for (String string : ctrl.getListIns()) {
            listInst1.add(string);
        }
        ArrayList<String> listInst2 = new ArrayList<>();
        ctrl.remplirListIns(auto2);
        for (String string : ctrl.getListIns()) {
            listInst2.add(string);
        }

        //Déclarations pour l'automate Résultat
        List<String> listS = interSet(listS1, listS2);//faire l'intersection de l'ensemble d'alphabet
        List<String> listEnsEtats = new ArrayList();//Liste des états
        List<String> listEF = new ArrayList();//Liste des états//Liste des états finaux
        String etatInit = "";
        ArrayList<String> listInst = new ArrayList();//Liste d'instruction du nouvel automate
        //recuperer les etats initiaux
        SI1 = auto1.getEtatInitial();
        SI2 = auto2.getEtatInitial();
        etatInit = "(" + SI1 + "," + SI2 + ")";
        listEnsEtats.add("(" + SI1 + "," + SI2 + ")");
        int j = 0;
        while (j < listEnsEtats.size()) {//parcourir la liste des instructions
            String tab[] = listEnsEtats.get(j).replaceAll(" ", "").split(",");
            SI1 = tab[0].substring(1, tab[0].length());
            SI2 = tab[1].substring(0, tab[1].length() - 1);
            for (int i = 0; i < listS.size() - 1; i++) {//parcourir la liste d'alphabet
                tmp1 = auto1.SixiSj(SI1, listS.get(i).charAt(0), listInst1);
                tmp2 = auto2.SixiSj(SI2, listS.get(i).charAt(0), listInst2);
                if (!tmp1.equals("0") && !tmp2.equals("0")) {
                    //ajouter l'état à l'ens d'états
                    tmp = "(" + tmp1 + "," + tmp2 + ")";
                    if (!listEnsEtats.contains(tmp)) {
                        listEnsEtats.add(tmp);
                    }
                    if (listEF1.contains(tmp1) && listEF2.contains(tmp2)) {
                        if (!listEF.contains(tmp)) {
                            listEF.add(tmp);//ajouter à la liste des états finaux
                        }
                    }
                    //ajouter l'instruction à l'ens d'instructions
                    tmp = "(" + SI1 + "," + SI2 + ")" + " " + listS.get(i).charAt(0) + " " + "(" + tmp1 + "," + tmp2 + ")";
                    if (!listInst.contains(tmp)) {
                        listInst.add(tmp);
                    }
                }
            }
            j++;
        }
        //remplir l'automate Resultat
        autoResult.remplirAuto(listS, listEnsEtats, etatInit, listEF, listInst);

        return autoResult;
    }

    //recupérer l'intersection des deux listes en entrée
    private List interSet(List list1, List list2) {
        List listResult = new ArrayList();
        if (list1.size() < list2.size()) {
            for (Object object : list1) {
                if (list2.contains(object)) {
                    if (!listResult.contains(object)) {
                        listResult.add(object);
                    }
                }
            }
        } else {
            for (Object object : list2) {
                if (list1.contains(object)) {
                    if (!listResult.contains(object)) {
                        listResult.add(object);
                    }
                }
            }
        }
        return listResult;
    }
}
