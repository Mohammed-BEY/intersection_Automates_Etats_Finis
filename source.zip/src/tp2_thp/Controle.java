/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_thp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author mohammed_bey
 */
public class Controle {

    static private final List<String> listSymbols = new ArrayList<>(),//static:car on les modifie lors de complétition de l'auto
            listEtats = new ArrayList<>(),
            listEtatsF = new ArrayList<>(),
            listIns = new ArrayList<>();//liste des instructions
    static private final Map<String, String> tabEtatEquiv = new HashMap<>();

    public Map<String, String> getTabEtatEquiv() {
        return tabEtatEquiv;
    }

    public List<String> getListIns() {
        return listIns;
    }

    public List<String> getListSymbols() {
        return listSymbols;
    }

    public List<String> getListEtats() {
        return listEtats;
    }

    public List<String> getListEtatsF() {
        return listEtatsF;
    }

    public Controle() {

    }

    //remplir la liste des lettres (symboles)
    public void remplirListS(Automate auto) {
        listSymbols.clear();
        String messError = "";
        if (!((Alphabet) auto.contauto.getChildren().get(0)).tField1.getText().replaceAll(" ", "").equals("")) {
            String[] alphabet = ((Alphabet) auto.contauto.getChildren().get(0)).tField1.getText().split(",");
            for (String string : alphabet) {
                if (string.length() > 1) {
                    messError += "Attention! il y a un symbole constitué de 2 symboles.\n";
                }
                if (!listSymbols.contains(string)) {
                    listSymbols.add(string);
                } else {//le symbol existe dans la liste des symboles
                    messError += "Attention! il y a un symbol doublé.\n";
                }
            }
        } else {
            messError += "Attention! l'alphabet est vide.\n";
        }
        listSymbols.add(messError);
    }

    //remplir la liste des états
    public void remplirListE(Automate auto) {
        listEtats.clear();
        String messError = "";
        if (!((EnsEtats) auto.contauto.getChildren().get(1)).tField1.getText().replaceAll(" ", "").equals("")) {
            String[] etats = ((EnsEtats) auto.contauto.getChildren().get(1)).tField1.getText().split(",");
            for (String string : etats) {
                try {
                    Double.parseDouble(string);
                    messError += "Attention! vous avez écrit un état constitué uniquement des chiffres.\n";
                } catch (NumberFormatException e) {
                    if (!listEtats.contains(string)) {
                        listEtats.add(string);
                    } else {//le symbol existe dans la liste des symboles
                        messError += "Attention! il y a un état doublé.\n";
                    }
                }
            }
        } else {
            messError += "Attention! l'ensemble des états est vide.\n";
        }
        listEtats.add(messError);
    }

    //remplir la liste des états finaux
    public void remplirListEF(Automate auto) {
        listEtatsF.clear();
        String messError = "";
        if (!((EnsEtatsFinaux) auto.contauto.getChildren().get(3)).tField1.getText().replaceAll(" ", "").equals("")) {
            String[] etatsF = ((EnsEtatsFinaux) auto.contauto.getChildren().get(3)).tField1.getText().split(",");
            for (String string : etatsF) {
                try {
                    Double.parseDouble(string);
                    messError += "Attention! vous avez écrit un état final constitué uniquement des chiffres.\n";
                } catch (NumberFormatException e) {
                    if (!listEtatsF.contains(string)) {
                        listEtatsF.add(string);
                    } else {//l'état est déjà utilisé
                        messError += "Attention! il y a un état final doublé.\n";
                    }
                }
            }
        } else {
            messError += "Attention! l'ensemble des états finaux est vide.\n";
        }
        listEtatsF.add(messError);
    }

    //remplir la liste des états
    public void remplirListEIntersection(Automate auto) {
        listEtats.clear();
        String messError = "", tmp = "", string = "";
        int i = 0, j = 0,
                indice = 0;
        tmp = ((EnsEtats) auto.contauto.getChildren().get(1)).tField1.getText().replaceAll(" ", "");
        if (!tmp.equals("")) {
            boolean fin = false;
            while (!fin) {
                j = tmp.indexOf("),", j + 1) + 1;
                if (j == 0) {
                    fin = true;
                    j = tmp.length();
                }
                string = tmp.substring(i, j);
                try {
                    Double.parseDouble(string);
                    messError += "Attention! vous avez écrit un état constitué uniquement des chiffres.\n";
                } catch (NumberFormatException e) {
                    if (!listEtats.contains(string)) {
                        listEtats.add(string);
                        tabEtatEquiv.put(string, "E" + Integer.toString(indice));
                        indice++;
                    } else {//le symbol existe dans la liste des symboles
                        messError += "Attention! il y a un état doublé.\n";
                    }
                }
                i = j + 1;
            }
        } else {
            messError += "Attention! l'ensemble des états est vide.\n";
        }
        listEtats.add(messError);
    }

    //remplir la liste des états finaux de l'auto intersection
    public void remplirListEFIntersection(Automate auto) {
        listEtatsF.clear();
        String messError = "", tmp = "", string = "";
        int i = 0, j = 0;
        tmp = ((EnsEtatsFinaux) auto.contauto.getChildren().get(3)).tField1.getText().replaceAll(" ", "");
        if (!tmp.equals("")) {
            boolean fin = false;
            while (!fin) {
                j = tmp.indexOf("),", j + 1) + 1;
                if (j == 0) {
                    fin = true;
                    j = tmp.length();
                }
                string = tmp.substring(i, j);
                try {
                    Double.parseDouble(string);
                    messError += "Attention! vous avez écrit un état final constitué uniquement des chiffres.\n";
                } catch (NumberFormatException e) {
                    if (!listEtatsF.contains(string)) {
                        listEtatsF.add(string);
                    } else {//l'état est déjà utilisé
                        messError += "Attention! il y a un état final doublé.\n";
                    }
                }
                i = j + 1;
            }
        } else {
            messError += "Attention! l'ensemble des états finaux est vide.\n";
        }
        listEtatsF.add(messError);
    }

    //remplir la liste des instructions
    public void remplirListIns(Automate auto) {
        listIns.clear();
        int j = auto.contauto.getChildren().size();
        String tmp = "", messError = "", ch = "";
        for (int k = 5; k < j; k++) {
            ch = auto.contauto.getChildren().get(k).toString();
            tmp = auto.contauto.getChildren().get(k).toString().substring(0, ch.length() - 1);
            if (!listIns.contains(tmp)) {
                listIns.add(tmp);
            } else {
                messError += "Attetion! l'instruction '" + tmp + "' est doublée.\n";
            }
        }
        listIns.add(messError);
    }
}
