/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_thp;

/**
 *
 * @author mohammed_bey
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

//La classe Boite de dialogue de la confirmation de la suppression d'un bloc d'instructions et les modules internes
public class BoiteDeDialogue extends Group {

    final Stage stage;
    TextArea txtError;

    public BoiteDeDialogue(String str) {
        txtError = new TextArea(str);
        ImageView image = new ImageView(new Image(TP2_THP.class.getResourceAsStream("images/info.png")));
        image.setFitHeight(60);
        image.setPreserveRatio(true);
        //ajouter les elements au groupe
        getChildren().addAll(image, txtError);
        txtError.setLayoutX(70);
        txtError.setLayoutY(13);
        txtError.setEditable(false);
        txtError.setStyle("-fx-border-style:solid;\n"
                + "    -fx-border-color:#690033;\n"
                + "    -fx-background-color:white;");
        image.setLayoutY(30);
        stage = new Stage();
        stage.setResizable(false);
        stage.setScene(new Scene(this, 530, 180));
        stage.show();
        stage.setTitle("   erreur détectée  ");
    }
}
