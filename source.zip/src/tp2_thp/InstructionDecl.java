/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_thp;

import java.util.List;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author mohammed_bey
 */
public class InstructionDecl extends ClasseMereGraphique {

    protected final iconeMajInst icMAJ;

    public InstructionDecl(AnchorPane contauto) {
        icMAJ = new iconeMajInst();
        tField1.setPromptText("Si");
        tField3.setPromptText("Sj");
        tField2.setPromptText("  xi ");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        tField3.setPrefWidth(longChar(tField3.getPromptText()));
        getChildren().addAll(tField1, tField2, tField3, icMAJ);
        tField2.setPrefWidth(30);
        tField2.textProperty().addListener((ObservableValue<? extends String> ov, String t, String t1) -> {
            String str = tField2.getText().replaceAll(" ", "");
            if (str.length() == 1) {
                tField2.setText("   " + str);
            } else if (str.length() == 0) {
                tField2.setText("");
                tField2.setPrefWidth(30);
            } else {
                tField2.deleteNextChar();
            }
        });
        tField3.setOnAction((ActionEvent e) -> {
            ajouterEl(new InstructionDecl(contauto), contauto);
        });
        //Gérer les evenements sur les menus de MiseÀjour:
        icMAJ.setVisible(false);
        //le menu de MiseAjour apprait quand la souris entre dans la zone de l'objet
        setOnMouseEntered((Event t) -> {
            icMAJ.setVisible(true);
        });
        //le menu de MiseAjour disparait quand la souris sort de la zone de l'objet
        setOnMouseExited((Event t) -> {
            icMAJ.setVisible(false);
        });
        icMAJ.menuAjouter.setOnAction((ActionEvent e) -> {
            ajouterEl(new InstructionDecl(contauto), contauto);
        });
        icMAJ.menuSupprimer.setOnAction((ActionEvent e) -> {
            int indice = contauto.getChildren().indexOf(icMAJ.getParent());
            supprimerEl(indice, contauto);
        });
    }

    //remplir les champs de l'instruction à partir de str
    public void setInst(String str) {
        String[] tab = str.split(" ");
        int i = 0;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            tField2.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            tField3.setText(tab[i]);
            i++;
        }
    }

    @Override
    public String toString() {
        return tField1.getText() + " " + tField2.getText().replaceAll(" ", "") + " " + tField3.getText() + ",";
    }

    //contrôler l'utilisation des symbols et les états
    public String traiter(List listSymb, List listEtat) {
        String result = "";
        if (!listSymb.contains(tField2.getText().replaceAll(" ", ""))) {//on a utilisé un symbole non déclaré
            result += "Attention! le symbol '" + tField2.getText().replaceAll(" ", "") + "' dans une instruction n'a pas été défini.\n";
        }
        try {//pour Si
            Double.parseDouble(tField1.getText());
            result += "Attetntion! l'état '" + tField1.getText().replaceAll(" ", "") + "' dans une instruction est constitué uniquement des chiffres.\n";
        } catch (NumberFormatException e1) {
            if (!listEtat.contains(tField1.getText().replaceAll(" ", ""))) {//on a utilisé un état non déclaré
                result += "Attention! l'état '" + tField1.getText().replaceAll(" ", "") + "' dans une instruction n'a pas été défini.\n";
            }
        }
        try {//pour Sj
            Double.parseDouble(tField3.getText());
            result += "Attetntion! l'état '" + tField3.getText().replaceAll(" ", "") + "' dans une instruction est constitué uniquement des chiffres.\n";
        } catch (NumberFormatException e1) {
            if (!listEtat.contains(tField3.getText().replaceAll(" ", ""))) {//on a utilisé un état non déclaré
                result += "Attention! l'état '" + tField3.getText().replaceAll(" ", "") + "' dans une instruction n'a pas été défini.\n";
            }
        }
        return result;
    }

    //La methode d'ajout d'un element
    public void ajouterEl(InstructionDecl el, AnchorPane contauto) {
        contauto.getChildren().add(el);
        double posY = contauto.getChildren().get(contauto.getChildren().size() - 2).getLayoutY();
        int index = contauto.getChildren().size() - 1;
        switch (index % 3) {
            case 2:
                if (contauto.getChildren().size() == 6) {//la premiere instruction
                    el.setLayoutY(23 * 4);
                } else {//nouvelle ligne
                    el.setLayoutY(posY + 23);
                }
                el.setLayoutX(170);
                break;
            case 0:
                el.setLayoutY(posY);
                el.setLayoutX(170 + 100);
                break;
            case 1:
                el.setLayoutY(posY);
                el.setLayoutX(170 + 100 + 100);
                break;
            default:
                throw new AssertionError();
        }
    }

    //La methode d'ajout d'unn instruction dans l'auto Intersection
    public void ajouterInstrInter(InstructionDecl el, AnchorPane contauto) {
        contauto.getChildren().add(el);
        double posY = contauto.getChildren().get(contauto.getChildren().size() - 2).getLayoutY();
        int index = contauto.getChildren().size() - 1;
        switch (index % 2) {
            case 1:
                if (contauto.getChildren().size() == 6) {//la premiere instruction
                    el.setLayoutY(23 * 4);
                } else {//nouvelle ligne
                    el.setLayoutY(posY + 23);
                }
                el.setLayoutX(170);
                break;
            case 0:
                el.setLayoutY(posY);
                el.setLayoutX(170 + 170);
                break;
            default:
                throw new AssertionError();
        }
    }

    //La methode de suppression
    public void supprimerEl(int index, AnchorPane contauto) {
        contauto.getChildren().remove(index);
        int j = contauto.getChildren().size();
        double posY;
        for (int i = index; i < j; i++) {
            switch (i % 3) {
                case 2:
                    contauto.getChildren().get(i).setLayoutX(170);
                    break;
                case 0:
                    contauto.getChildren().get(i).setLayoutX(170 + 100);
                    break;
                case 1://il étatit dans la ligne précédente
                    posY = contauto.getChildren().get(i).getLayoutY();
                    contauto.getChildren().get(i).setLayoutY(posY - 23);
                    contauto.getChildren().get(i).setLayoutX(170 + 100 + 100);
                    break;
                default:
                    throw new AssertionError();
            }
        }
    }
}
