/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_thp;

/**
 *
 * @author mohammed_bey
 */
public class EnsEtats extends ClasseMereGraphique {

    public EnsEtats() {
        label1.setText("Ensemble des états = { ");
        label2.setText(" }");
        tField1.setPromptText("S0,S1,...,Sn");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(label1, tField1, label2);
    }
    
    @Override
    public String toString() {
        return "Ensemble des états = {" + tField1.getText() + "}\n";
    }

}
