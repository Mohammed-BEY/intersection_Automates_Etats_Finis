/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_thp;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author mohammed_bey
 */
public class FXMLDocumentController implements Initializable {

    //le conteneur principal de l'Editeur
    @FXML
    ScrollPane sp;
    @FXML
    ScrollPane sp2;
    @FXML
    ScrollPane spInters;
    @FXML
    TextField tfMot;//ecrire le mot à reconnaitre
    @FXML
    TextArea txChemin;//afficher tous les états pour obtenir le mot demandé par l'utilisateur
    @FXML
    TextArea txEtatEquiv;//afficher les états quivalents des états de l'auto Intersection
    @FXML
    public AnchorPane contauto = new AnchorPane(),//conteneur des objets
            contauto2 = new AnchorPane(),//conteneur des objets du deuxieme automate
            contauto3 = new AnchorPane();//conteneur des objets de l'auto Intersection
    private Automate auto, auto2, auto3;
    private BoiteDeDialogue boxError1, boxError2, boxError3 = null;

    @FXML
    void afficherAutoIntersection() throws IOException, InterruptedException {
        traiterAutoIntersection();
        if (boxError3.txtError.getText().equals("il n'y a aucune erreur détectée.")) {
            File defaultDirectory = new File(".\\graphes");//initialiser le répertoire par défaut
            if (!defaultDirectory.exists()) {
                defaultDirectory.mkdir();
            }
            //****Sauvegarder l'état du graphe dans un fichier
            String NomFichier = ".\\graphes\\graph3.txt";
            try {
                try (PrintWriter out = new PrintWriter(new FileWriter(NomFichier))) {
                    out.println(auto3.graphStatusIntersection(contauto3));
                }
            } catch (IOException e) {
            }
            try {
                Runtime.getRuntime().exec(".\\graphviz\\dot.exe -Tpng "
                        + defaultDirectory + "\\graph3.txt -o "
                        + defaultDirectory + "\\auto3.png").waitFor();
            } catch (IOException ex) {
            }
            String[] commands = {
                "cmd.exe", "/c", "start", "\"DummyTitle\"", "\"" + ".\\graphes\\auto3.png" + "\""
            };
            Process p = Runtime.getRuntime().exec(commands);
            try {
                p.waitFor();
            } catch (InterruptedException ex) {
            }
            txEtatEquiv.setText(auto3.etatsEquiv());
        }
    }

    @FXML
    void afficherAuto1() throws IOException, InterruptedException {
        traiterAuto1();
        if (boxError1.txtError.getText().equals("il n'y a aucune erreur détectée.")) {
            File defaultDirectory = new File(".\\graphes");//initialiser le répertoire par défaut
            if (!defaultDirectory.exists()) {
                defaultDirectory.mkdir();
            }
            //****Sauvegarder l'état du graphe dans un fichier
            String NomFichier = ".\\graphes\\graph1.txt";
            try {
                try (PrintWriter out = new PrintWriter(new FileWriter(NomFichier))) {
                    out.println(auto.graphStatus(contauto));
                }
            } catch (IOException e) {
            }
            try {
                Runtime.getRuntime().exec(".\\graphviz\\dot.exe -Tpng "
                        + defaultDirectory + "\\graph1.txt -o "
                        + defaultDirectory + "\\auto1.png").waitFor();
            } catch (IOException ex) {
            }
            String[] commands = {
                "cmd.exe", "/c", "start", "\"DummyTitle\"", "\"" + ".\\graphes\\auto1.png" + "\""
            };
            Process p = Runtime.getRuntime().exec(commands);
            try {
                p.waitFor();
            } catch (InterruptedException ex) {
            }
        }
    }

    @FXML
    void afficherAuto2() throws IOException, InterruptedException {
        traiterAuto2();
        if (boxError2.txtError.getText().equals("il n'y a aucune erreur détectée.")) {
            File defaultDirectory = new File(".\\graphes");//initialiser le répertoire par défaut
            if (!defaultDirectory.exists()) {
                defaultDirectory.mkdir();
            }
            //****Sauvegarder l'état du graphe dans un fichier
            String NomFichier = ".\\graphes\\graph2.txt";
            try {
                try (PrintWriter out = new PrintWriter(new FileWriter(NomFichier))) {
                    out.println(auto2.graphStatus(contauto2));
                }
            } catch (IOException e) {
            }
            try {
                Runtime.getRuntime().exec(".\\graphviz\\dot.exe -Tpng "
                        + defaultDirectory + "\\graph2.txt -o "
                        + defaultDirectory + "\\auto2.png").waitFor();
            } catch (IOException ex) {
            }
            String[] commands = {
                "cmd.exe", "/c", "start", "\"DummyTitle\"", "\"" + ".\\graphes\\auto2.png" + "\""
            };
            Process p = Runtime.getRuntime().exec(commands);
            try {
                p.waitFor();
            } catch (InterruptedException ex) {
            }
        }
    }

    @FXML
    void recoonaitreUnMot() {
        traiterAutoIntersection();
        if (boxError3.txtError.getText().equals("il n'y a aucune erreur détectée.")) {
            if (tfMot.getText().equals("")) {
                txChemin.setText("Veuillez donner un mot.");
            } else {
                System.out.println("error:" + auto3.traiterIntersection(contauto3));
                if (auto3.traiterIntersection(contauto3).equals("")) {//il n'y a aucune erreur détectée
                    boolean reconnu = auto3.reconnaitreMot(tfMot.getText(), contauto3);
                    if (reconnu) {
                        txChemin.setText(auto3.chemin);
                    } else {
                        txChemin.setText("Le mot introduit n'est reconnu par cet automate.");
                    }
                } else {
                    txChemin.setText("Veuillez vérifier l'automate, il comporte des erreurs.");
                }
            }
        }
    }

    @FXML
    void traiterAutoIntersection() {
        if (auto3 != null && !auto3.estVide(contauto3)) {
            String tmp = auto3.traiterIntersection(contauto3);
            if (tmp.equals("")) {
                boxError3 = new BoiteDeDialogue("il n'y a aucune erreur détectée.");
            } else {
                boxError3 = new BoiteDeDialogue(tmp);
            }
        } else {
            //afficher un message d'erreur
            if (auto3 == null) {
                boxError3 = new BoiteDeDialogue("Désolé! l'automate n'est pas encore construit.");
            } else {
                boxError3 = new BoiteDeDialogue("Veuillez remplir tous les champs de l'automate.");
            }
        }
    }

    @FXML
    void traiterAuto1() {
        if (!auto.estVide(contauto)) {
            String tmp = auto.traiter(contauto);
            if (tmp.equals("")) {
                boxError1 = new BoiteDeDialogue("il n'y a aucune erreur détectée.");
            } else {
                boxError1 = new BoiteDeDialogue(tmp);
            }
        } else {
            //afficher un message d'erreur
            boxError1 = new BoiteDeDialogue("Veuillez remplir tous les champs de l'automate.");
        }
    }

    @FXML
    void traiterAuto2() {
        if (!auto2.estVide(contauto2)) {
            String tmp = auto2.traiter(contauto2);
            if (tmp.equals("")) {
                boxError2 = new BoiteDeDialogue("il n'y a aucune erreur détectée.");
            } else {
                boxError2 = new BoiteDeDialogue(tmp);
            }
        } else {
            //afficher un message d'erreur
            boxError2 = new BoiteDeDialogue("Veuillez remplir tous les champs de l'automate.");
        }
    }

    @FXML
    void intersectionAutos() {
        IntersectionAuto autoInters = new IntersectionAuto();
        auto3 = autoInters.intersection(auto, auto2, contauto3);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        auto = new Automate(contauto);
        auto2 = new Automate(contauto2);

        sp.setContent(contauto);
        sp2.setContent(contauto2);
        spInters.setContent(contauto3);

        contauto.getStyleClass().add("anchorpane");
        contauto2.getStyleClass().add("anchorpane");
        contauto3.getStyleClass().add("anchorpane");
        tfMot.setOnAction((ActionEvent e) -> {
            recoonaitreUnMot();
        });
    }
}
