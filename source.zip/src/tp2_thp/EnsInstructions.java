/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_thp;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author mohammed_bey
 */
public class EnsInstructions extends ClasseMereGraphique {

    protected final iconeMajInst icMAJ;

    public EnsInstructions(AnchorPane contauto) {
        icMAJ = new iconeMajInst();
        icMAJ.menuSupprimer.setDisable(true);
        label1.setText("Ensemble des instructions : ");
        getChildren().addAll(label1, icMAJ);
        icMAJ.menuAjouter.setOnAction((ActionEvent e) -> {
            ajouterEl(new InstructionDecl(contauto), contauto);
        });
        //le menu de MiseAjour apprait quand la souris entre dans la zone de l'objet
        setOnMouseEntered((Event t) -> {
            icMAJ.setVisible(true);
        });
        //le menu de MiseAjour disparait quand la souris sort de la zone de l'objet
        setOnMouseExited((Event t) -> {
            icMAJ.setVisible(false);
        });
    }

    @Override
    public String toString() {
        return "Ensemble des instructions = {";
    }

    //La methode d'ajout d'un element
    public void ajouterEl(InstructionDecl el, AnchorPane contauto) {
        contauto.getChildren().add(el);
        double posY = contauto.getChildren().get(contauto.getChildren().size() - 2).getLayoutY();
        int index = contauto.getChildren().size() - 1;
        switch (index % 3) {
            case 2:
                if (contauto.getChildren().size() == 6) {//la premiere instruction
                    el.setLayoutY(23 * 4);
                } else {//nouvelle ligne
                    el.setLayoutY(posY + 23);
                }
                el.setLayoutX(170);
                break;
            case 0:
                el.setLayoutY(posY);
                el.setLayoutX(170 + 100);
                break;
            case 1:
                el.setLayoutY(posY);
                el.setLayoutX(170 + 100 + 100);
                break;
            default:
                throw new AssertionError();
        }
    }
}
